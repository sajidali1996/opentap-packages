"""Shared OpenTAP services for the inverter plugin."""

import OpenTap

LOG = OpenTap.Log.CreateSource("Inverter Automation")


def _log(method_name, fallback_name, message, *args):
	method = getattr(LOG, method_name, None)
	if callable(method):
		method(message, *args)
		return

	fallback = getattr(LOG, fallback_name, None)
	if callable(fallback):
		fallback(message, *args)


def log_info(message, *args):
	_log("Info", "Warning", message, *args)


def log_warning(message, *args):
	_log("Warning", "Error", message, *args)


def log_error(message, *args):
	_log("Error", "Warning", message, *args)
